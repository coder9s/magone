(function ($) {
	if (typeof(Sneeit_Sticky_Columns) == 'undefined' || !Sneeit_Sticky_Columns || $(Sneeit_Sticky_Columns).length == 0) {		
		return;
	}

	// Clone a fake column
	var SSC_Index = 0;
	$(Sneeit_Sticky_Columns).each(function(){		
		var id = $(this).attr('id');
		var cl = $(this).attr('class');
		var style = $(this).attr('style');
		var clone = '<div';
		if (typeof(id) != 'undefined') {
			clone += ' id="'+id+'"';
		}
		if (typeof(cl) != 'undefined') {
			clone += ' class="'+cl+'"';
		}
		if (typeof(style) != 'undefined') {
			clone += ' style="'+style+'"';
		}
		clone += '></div>';
		
		$(this).parent().css('position', 'relative').find('> *').each(function(){
			if (!$(this).is(Sneeit_Sticky_Columns)) {
				$(this).addClass('ssc-disable');
			}
		});
		
		$(clone).insertBefore($(this)).css('display', 'none').addClass('ssc-clone-'+SSC_Index);
		$(this).attr('data-ssc', '.ssc-clone-'+SSC_Index).addClass('ssc-enable');
		SSC_Index++;
	});
	
	var SSC_PrevWinTop = 0;
	var SSC_Off_Top = 0; 
	function sneeit_sticky_columns() {
		// window info
		var win_top = $(window).scrollTop();
		var win_hei = $(window).height();
		var win_bot = win_top + win_hei;
		
		/* we must have offset on top in case 
		 * have an element is fixing to prevent hide of column's top */
		if ($('.sneeit-compact-menu-sticky').height()) {
			SSC_Off_Top = $('.sneeit-compact-menu-sticky').height();			
		}
		$('.ssc-enable').each(function(){
			var clone = $($(this).attr('data-ssc'));
			clone.show();
			var col_top = clone.offset().top;			
			var col_wid = clone.width();
			clone.hide();
			if (win_top < col_top) {				
				clone.hide();
				$(this).css({
					'position' : '',
					'top': '',
					'left': '',	
					'bottom' : '',
					'max-width' : '',
				}).removeClass('ssc-fixing');
				return;
			}
			var col_hei = $(this).height();
			
			// find referer which has max height
			var max_hei = 0;			
			$(this).parent().find('> .ssc-disable').each(function(){				
				var hei = $(this).height();
				if ($(this).offset().top == col_top && hei > max_hei) {
					max_hei = hei;			
				}
			});
						
			// found nothing to refer or
			// found one, but its height even lower than this col			
			if (!max_hei || max_hei < col_hei) {								
				clone.hide();
				$(this).css({
					'position' : '',
					'top': '',
					'left': '',
					'bottom' : '',
					'max-width' : '',
				}).removeClass('ssc-fixing');
				return;
			}
			
			/* everything is ok, now we calculate the fixed status */
			var col_real_top = $(this).offset().top;
			var col_real_bot = col_real_top + col_hei;
			var ref_bot = col_top + max_hei;
			
			/* in case the col hei is too low */
			if (col_hei <= win_hei) {				
				var off_top = 0;
				if ($('.sneeit-compact-menu-sticky').length) {
					off_top = $('.sneeit-compact-menu-sticky').height();					
				}				
				if (win_top < col_real_top || win_top > col_top && col_real_bot < ref_bot) {					
					clone.show();
					$(this).css({
						'position' : 'fixed',
						'top': off_top+'px',
						'bottom' : '',
						'left': clone.offset().left + 'px',
						'max-width': col_wid+'px'
					});
				} else {
					clone.hide();
					$(this).css({
						'position' : 'relative',
						'top': (max_hei - col_hei) + 'px',
						'left': clone.offset().left + 'px',
						'bottom' : '', 
						'max-width': col_wid+'px'
					});
				}
			} 
			/* normal col hei is larger than win hei , most of cases*/
			else {
				/* the bottom will over the ref bottom
				 * so just keep the bottom of the col
				 * equal to the ref bot */
				if (win_bot >= ref_bot) {
					clone.hide();
					$(this).css({
						'position' : 'relative',
						'top': (max_hei - col_hei) + 'px',
						'left': clone.offset().left + 'px',
						'bottom' : '', 
						'max-width': col_wid+'px'
					});	
				}
				/* is scrolling up */
				else if (win_top < SSC_PrevWinTop) {
					/* this is not fixing bottom */
					if (col_real_top < col_top) {
						clone.hide();
						$(this).css({
							'position' : '',
							'top': '',
							'left': '',
							'bottom' : '',
							'max-width' : '',
						}).removeClass('ssc-fixing');
					} else if (col_real_top > win_top + SSC_Off_Top) {
						clone.show();
						$(this).css({
							'position' : 'fixed',
							'top': SSC_Off_Top+'px',
							'bottom' : '',
							'left': clone.offset().left + 'px',
							'max-width': col_wid+'px'
						});						
					} else if ($(this).css('bottom') == '0px' && $(this).css('position') == 'fixed') {
						clone.hide();
						$(this).css({
							'position' : 'relative',
							'top': (col_real_top - col_top) + 'px',
							'left': '',
							'bottom' : '',
							'max-width' : '',
						});						
					}
				}
				/* if scrolling down */
				else if (win_top >= SSC_PrevWinTop) {					
					
					/* this is not fixing top */
					if (col_real_bot > ref_bot) {						
						clone.hide();						
						$(this).css({
							'position' : 'relative',
							'top': (max_hei - col_hei) + 'px',
							'left': clone.offset().left + 'px',
							'bottom' : '', 
							'max-width': col_wid+'px'
						});
					} else if (col_real_bot < win_bot) {
						clone.show();						
						$(this).css({
							'position' : 'fixed',
							'top': '',
							'bottom' : '0px',
							'left': clone.offset().left + 'px',
							'max-width': col_wid+'px'
						});				   
					} else if ($(this).css('top') == (SSC_Off_Top+'px') && $(this).css('position') == 'fixed') {
						clone.hide();
						$(this).css({
							'position' : 'relative',
							'top': (col_real_top - col_top) + 'px',
							'left': '',
							'bottom' : '',
							'max-width' : '',
						});						
					}
				}
			}
			
			
			
		});
	}
	
	sneeit_sticky_columns();
	
	// sticky sidebar when scrolling
	$(window).scroll(function() {
		sneeit_sticky_columns();
		SSC_PrevWinTop = $(window).scrollTop();
	});	
	$( document ).ajaxComplete(function() {
		sneeit_sticky_columns();		
	});
	
		
}) (jQuery);